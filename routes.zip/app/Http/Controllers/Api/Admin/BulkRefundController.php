<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Tenant\EquityTransaction;
use App\Models\Tenant\Member;
use App\Models\Tenant\Refund;
use App\Models\Tenant\Wallet;
use App\Models\Tenant\WalletTransaction;
use App\Traits\HandlesBulkFileUpload;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class BulkRefundController extends Controller
{
    use HandlesBulkFileUpload;
    public function downloadTemplate(): JsonResponse
    {
        // Helper function to escape CSV values
        $escapeCsv = function($value) {
            // If value contains comma, quote, or newline, wrap in quotes and escape internal quotes
            if (strpos($value, ',') !== false || strpos($value, '"') !== false || strpos($value, "\n") !== false) {
                return '"' . str_replace('"', '""', $value) . '"';
            }
            return $value;
        };

        $headers = [
            'Member ID (UUID, Staff ID, or IPPIS)',
            'Amount',
            'Source (contribution/investment_return/investment/equity_wallet)',
            'Reason',
            'Notes'
        ];

        $sampleData = [
            [
                'FRSC/HMS/2024/001',
                '50000',
                'contribution',
                'Refund for overpayment',
                'Overpayment refund processed'
            ],
            [
                'FRSC/HMS/2024/002',
                '75000',
                'investment_return',
                'Early withdrawal refund',
                'Investment return processed'
            ],
        ];

        $csvContent = implode(',', array_map($escapeCsv, $headers)) . "\n";
        foreach ($sampleData as $row) {
            $csvContent .= implode(',', array_map($escapeCsv, $row)) . "\n";
        }

        return response()->json([
            'success' => true,
            'template' => $csvContent,
            'filename' => 'refunds_upload_template.csv'
        ]);
    }

    public function uploadBulk(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthenticated',
                    'errors' => ['You must be logged in to perform this action.'],
                    'error_type' => 'authentication_error'
                ], 401);
            }

            $validator = Validator::make($request->all(), [
                'file' => 'required|file|mimes:csv,txt,xlsx,xls|max:5120',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'File validation failed',
                    'errors' => $validator->errors()->all(),
                    'error_type' => 'file_validation'
                ], 422);
            }

            $file = $request->file('file');
            
            if (!$file || !$file->isValid()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid or corrupted file',
                    'errors' => ['The uploaded file is invalid or corrupted. Please check the file and try again.'],
                    'error_type' => 'file_invalid'
                ], 422);
            }

            $parsedResult = $this->parseFile($file);
            
            if (!$parsedResult['success']) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to parse file',
                    'errors' => $parsedResult['errors'] ?? ['Unable to parse the file. Please check the file format.'],
                    'error_type' => 'parsing_error'
                ], 422);
            }

            $rows = $parsedResult['data'];
            
            if (empty($rows)) {
                return response()->json([
                    'success' => false,
                    'message' => 'No refund data found in file',
                    'errors' => ['The file appears to be empty or contains no valid refund data.'],
                    'error_type' => 'empty_data'
                ], 422);
            }

            $successful = 0;
            $failed = 0;
            $errors = $parsedResult['errors'] ?? [];

            DB::beginTransaction();
            foreach ($rows as $index => $data) {
                $lineNumber = $index + 2; // +2 because line 1 is header

                try {
                    // Helper function to find value by multiple possible keys (case-insensitive, handles whitespace)
                    $findValue = function($keys, $default = '') use ($data) {
                        foreach ($keys as $key) {
                            // Try exact match first
                            if (array_key_exists($key, $data)) {
                                $value = trim((string)$data[$key]);
                                if ($value !== '') {
                                    return $value;
                                }
                            }
                            // Try case-insensitive match
                            foreach ($data as $dataKey => $dataValue) {
                                $normalizedKey = trim((string)$dataKey);
                                $normalizedSearchKey = trim((string)$key);
                                
                                // Exact case-insensitive match
                                if (strcasecmp($normalizedKey, $normalizedSearchKey) === 0) {
                                    $value = trim((string)$dataValue);
                                    if ($value !== '') {
                                        return $value;
                                    }
                                }
                                
                                // Partial match for headers with parentheses
                                $keyWithoutParentheses = preg_replace('/\s*\([^)]*\)\s*/', '', $normalizedKey);
                                $searchKeyWithoutParentheses = preg_replace('/\s*\([^)]*\)\s*/', '', $normalizedSearchKey);
                                if (strcasecmp(trim($keyWithoutParentheses), trim($searchKeyWithoutParentheses)) === 0) {
                                    $value = trim((string)$dataValue);
                                    if ($value !== '') {
                                        return $value;
                                    }
                                }
                            }
                        }
                        return $default;
                    };

                    // Extract values using flexible header matching
                    $memberId = $findValue([
                        'Member ID (UUID, Staff ID, or IPPIS)',
                        'Member ID (UUID or Staff ID)',
                        'member_id_uuid_staff_id_or_ippis',
                        'member_id_uuid_or_staff_id',
                        'Member ID',
                        'member_id',
                        'MemberID',
                        'MemberId',
                        'Member Number',
                        'member_number',
                        'Staff ID',
                        'staff_id'
                    ]);
                    
                    $amount = $findValue([
                        'Amount',
                        'amount'
                    ]);
                    
                    $source = $findValue([
                        'Source (contribution/investment_return/investment/equity_wallet)',
                        'source_contribution_investment_return_investment_equity_wallet',
                        'Source',
                        'source'
                    ], 'contribution');
                    
                    $reason = $findValue([
                        'Reason',
                        'reason'
                    ]);
                    
                    $notes = $findValue([
                        'Notes',
                        'notes'
                    ]);

                    // Validate required fields
                    if (empty($memberId)) {
                        $availableKeys = implode(', ', array_keys($data));
                        $errors[] = "Row {$lineNumber}: Member ID is required. Available columns: {$availableKeys}";
                        $failed++;
                        continue;
                    }

                    if (empty($amount) || !is_numeric($amount) || floatval($amount) <= 0) {
                        $errors[] = "Row {$lineNumber}: Amount is required and must be greater than 0";
                        $failed++;
                        continue;
                    }

                    if (empty($source)) {
                        $availableKeys = implode(', ', array_keys($data));
                        $errors[] = "Row {$lineNumber}: Source is required. Available columns: {$availableKeys}";
                        $failed++;
                        continue;
                    }

                    // Validate source value
                    $validSources = ['contribution', 'investment_return', 'investment', 'equity_wallet'];
                    if (!in_array(strtolower($source), $validSources)) {
                        $errors[] = "Row {$lineNumber}: Invalid source '{$source}'. Must be one of: " . implode(', ', $validSources);
                        $failed++;
                        continue;
                    }

                    $amount = floatval($amount);
                    $source = strtolower($source);

                    // Find member
                    $member = Member::with('user.wallet')->where('id', $memberId)
                        ->orWhere('member_number', $memberId)
                        ->orWhere('staff_id', $memberId)
                        ->orWhere('ippis_number', $memberId)
                        ->first();

                    if (!$member) {
                        $errors[] = "Row {$lineNumber}: Member not found for identifier '{$memberId}'. Please use Member Number, Staff ID, IPPIS Number, or Member UUID.";
                        $failed++;
                        continue;
                    }

                    if (!$member->user) {
                        $errors[] = "Row {$lineNumber}: Member '{$memberId}' does not have a user account";
                        $failed++;
                        continue;
                    }

                    // Handle different sources
                    $wallet = null;
                    $equityWallet = null;
                    $equityTransaction = null;

                    if ($source === 'equity_wallet') {
                        // For equity_wallet refunds, check equity wallet balance
                        $equityWallet = $member->equityWalletBalance;
                        if (!$equityWallet || $equityWallet->balance < $amount) {
                            $equityBalance = $equityWallet ? $equityWallet->balance : 0;
                            $errors[] = "Row {$lineNumber}: Insufficient equity wallet balance. Available: ₦" . number_format($equityBalance, 2) . ", Required: ₦" . number_format($amount, 2);
                            $failed++;
                            continue;
                        }
                    } else {
                        // For other sources, ensure wallet exists and check balance
                        $wallet = $member->user->wallet ?? Wallet::create(['user_id' => $member->user_id, 'balance' => 0]);

                        // Check wallet balance (all refunds except equity_wallet are paid from wallet)
                        // Note: For contribution/investment_return sources, the Refund record tracks
                        // how much was refunded from those sources, but the actual payment comes from wallet
                        if ($wallet->balance < $amount) {
                            $errors[] = "Row {$lineNumber}: Insufficient wallet balance. Available: ₦" . number_format($wallet->balance, 2) . ", Required: ₦" . number_format($amount, 2) . ". Source: {$source}";
                            $failed++;
                            continue;
                        }
                    }

                    // Generate reference
                    $reference = 'REF-' . strtoupper(Str::random(10));

                    // Create Refund record first
                    $refund = Refund::create([
                        'member_id' => $member->id,
                        'request_type' => 'refund',
                        'status' => 'completed', // Bulk uploads are processed immediately
                        'source' => $source,
                        'amount' => $amount,
                        'reason' => $reason,
                        'notes' => $notes,
                        'processed_by' => $user->id,
                        'approved_by' => $user->id,
                        'approved_at' => now(),
                        'processed_at' => now(),
                        'completed_at' => now(),
                        'reference' => $reference,
                        'metadata' => [
                            'bulk_upload' => true,
                            'processed_at' => now()->toIso8601String(),
                        ],
                    ]);

                    // Process refund based on source
                    $walletTransaction = null;

                    if ($source === 'equity_wallet') {
                        // Process equity wallet refund
                        $balanceBefore = (float) $equityWallet->balance;
                        $equityWallet->decrement('balance', $amount);
                        $equityWallet->increment('total_used', $amount);
                        $equityWallet->last_updated_at = now();
                        $equityWallet->save();

                        $equityTransaction = EquityTransaction::create([
                            'member_id' => $member->id,
                            'equity_wallet_balance_id' => $equityWallet->id,
                            'type' => 'refund',
                            'amount' => $amount,
                            'balance_before' => $balanceBefore,
                            'balance_after' => (float) $equityWallet->fresh()->balance,
                            'reference' => $reference,
                            'reference_type' => 'refund',
                            'description' => "Refund processed from equity wallet ({$reason})",
                            'notes' => $notes,
                            'metadata' => [
                                'processed_by' => $user->id,
                                'bulk_upload' => true,
                            ],
                        ]);
                    } else {
                        // Process wallet transaction (debit from wallet for payout)
                        // Note: For contribution/investment_return sources, the money still comes from wallet
                        // but we track it as refunded from those sources
                        $wallet->decrement('balance', $amount);

                        // Create wallet transaction record
                        $walletTransaction = WalletTransaction::create([
                            'wallet_id' => $wallet->id,
                            'type' => 'debit',
                            'amount' => $amount,
                            'description' => "Refund payout: {$reason} ({$source})",
                            'payment_reference' => $reference,
                            'status' => 'completed',
                            'balance_after' => (float) $wallet->fresh()->balance,
                            'metadata' => [
                                'refund_id' => $refund->id,
                                'source' => $source,
                                'reason' => $reason,
                                'notes' => $notes,
                                'processed_by' => $user->id,
                                'bulk_upload' => true,
                            ],
                        ]);
                    }

                    // Update refund metadata with transaction IDs
                    $refund->update([
                        'metadata' => array_merge($refund->metadata ?? [], [
                            'wallet_transaction_id' => $walletTransaction?->id,
                            'equity_transaction_id' => $equityTransaction?->id,
                        ]),
                    ]);

                    $successful++;
                } catch (\Illuminate\Database\QueryException $e) {
                    DB::rollBack();
                    $errorCode = $e->getCode();
                    $memberId = $memberId ?? 'unknown';
                    
                    if ($errorCode == 23000) {
                        $errors[] = "Row {$lineNumber} (Member: {$memberId}): Database constraint violation - " . $e->getMessage();
                    } else {
                        $errors[] = "Row {$lineNumber} (Member: {$memberId}): Database error - " . $e->getMessage();
                    }
                    $failed++;
                    Log::error("Bulk refund upload - Row {$lineNumber} database error", [
                        'error' => $e->getMessage(),
                        'data' => $data
                    ]);
                    DB::beginTransaction(); // Restart transaction for next row
                } catch (\Exception $e) {
                    Log::error("BulkRefundController error on row {$lineNumber}: " . $e->getMessage(), [
                        'trace' => $e->getTraceAsString(),
                        'data' => $data
                    ]);
                    $errors[] = "Row {$lineNumber}: " . $e->getMessage();
                    $failed++;
                }
            }

            DB::commit();
            
            // Check if all records failed
            if ($successful === 0 && $failed > 0) {
                return response()->json([
                    'success' => false,
                    'message' => 'All refund records failed to process',
                    'errors' => $errors,
                    'error_type' => 'processing_error',
                    'data' => [
                        'total' => count($rows),
                        'successful' => $successful,
                        'failed' => $failed,
                        'errors' => $errors,
                    ]
                ], 422);
            }

            // Partial success - some records succeeded, some failed
            if ($failed > 0) {
                return response()->json([
                    'success' => true,
                    'message' => "Bulk upload completed with errors. {$successful} successful, {$failed} failed.",
                    'data' => [
                        'total' => count($rows),
                        'successful' => $successful,
                        'failed' => $failed,
                        'errors' => $errors,
                    ],
                    'has_errors' => true
                ], 200);
            }

            return response()->json([
                'success' => true,
                'message' => "Bulk upload processed successfully. {$successful} successful.",
                'data' => [
                    'total' => count($rows),
                    'successful' => $successful,
                    'failed' => $failed,
                    'errors' => [],
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            
            Log::error('Bulk refund upload error: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'An unexpected error occurred during bulk upload',
                'errors' => ['Server error: ' . $e->getMessage()],
                'error_type' => 'server_error',
                'data' => [
                    'total' => isset($rows) ? count($rows) : 0,
                    'successful' => isset($successful) ? $successful : 0,
                    'failed' => isset($failed) ? $failed : 0,
                    'errors' => isset($errors) ? $errors : [],
                ]
            ], 500);
        }
    }
}


